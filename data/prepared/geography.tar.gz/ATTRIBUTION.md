# Source attribution

## Geographic data

© OpenStreetMap contributors. OpenStreetMap is available under the Open Database License (ODbL) 1.0: https://www.openstreetmap.org/copyright

The independently downloaded Geofabrik input is:
https://download.geofabrik.de/asia/kazakhstan-260924.osm.pbf

Source directory and licensing information:
https://download.geofabrik.de/asia/kazakhstan.html

The exact source timestamp, checksum, object IDs, original tags and administrative provenance are retained in `public/data/quality.json` and `docs/data-quality.md`. Derived GeoJSON data remains ODbL data. Attribute both OpenStreetMap contributors and the Geofabrik extract when redistributing it, and comply with ODbL database-sharing requirements where applicable.

OSM is community-maintained and can be incomplete or outdated. Height estimates are application assumptions, separately marked; source administrative boundaries are not a legal survey. Scenario fallback partitions, if needed, are explicitly approximate and distinct from the boundary export.

## Runtime

CesiumJS 1.145.0, Apache License 2.0, Cesium GS, Inc. License and bundled notices are preserved by `npm run vendor` in `public/vendor/cesium/` and the dependency lockfile. Cesium ion is not used. All application runtime resources are served locally.

## Reference screenshots

Existing screenshots in `google earth astana/` remain unmodified and are not published as application assets. They are visual references only. Their imagery, map labels, footprints, geographic geometry and textures were not extracted, traced or repurposed.
