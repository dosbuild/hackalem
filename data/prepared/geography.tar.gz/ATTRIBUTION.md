# Geographic data attribution

© OpenStreetMap contributors. This prepared geographic database and its derived
GeoJSON data are distributed under the Open Database License (ODbL) 1.0:
https://opendatacommons.org/licenses/odbl/1-0/
https://www.openstreetmap.org/copyright

Source: Geofabrik Kazakhstan extract, 24 September 2026.
https://download.geofabrik.de/asia/kazakhstan-260924.osm.pbf
https://download.geofabrik.de/asia/kazakhstan.html

Source timestamps, checksums, object IDs, tags and administrative provenance are
retained in data/quality.json, data/manifest.json and the GeoJSON records.
Retain OpenStreetMap attribution and comply with ODbL database-sharing terms
when redistributing this database or adaptations.

OSM is community-maintained and may be incomplete or outdated. Height estimates
are application assumptions; administrative boundaries are not a legal survey.
Fallback scenario partitions are explicitly approximate. The five scenario
districts are educational model inputs, not a claim about current legal limits.
